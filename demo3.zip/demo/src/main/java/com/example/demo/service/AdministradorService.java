package com.example.demo.service;

import com.example.demo.model.Administrador;
import com.example.demo.repository.AdministradorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdministradorService implements PersonagemService<Administrador> {
    @Autowired
    AdministradorRepository administradorRepository;

    @Override
    public List<Administrador> listar() {
        return administradorRepository.findAll();
    }

    @Override
    public Administrador criar(Administrador administrador) {
        return administradorRepository.save(administrador);
    }

    @Override
    public Administrador atualizar(Administrador administrador, Long id) {
        if(verificaID(id)) {
            administrador.setId(id);
            return administradorRepository.save(administrador);
        }
        return null;
    }

    @Override
    public boolean deletar(Long id) {
        if(administradorRepository.existsById(id)) {
            return true;
        } else {
            return false;
        }
    }

    private boolean verificaID(Long id) {
        if(administradorRepository.existsById(id)) {
            return true;
        } else {
            return false;
        }
    }

    public int qntAdministrador() {
        return administradorRepository.findAll().size();
    }

    public Optional<Administrador> buscaPorID(Long id) {
        return administradorRepository.findById(id);
    }
    public void deletarAll (){
        administradorRepository.deleteAll();
    }

}
