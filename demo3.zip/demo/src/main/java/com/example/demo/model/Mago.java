package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Mago extends Aprendiz{

    private double arcano;

    public Mago() {
    }

    public Mago(String apelido, int nivel, double vitalidade, double forca, double inteligencia, double agilidade, double destreza, double arcano) {
        super(apelido, nivel, vitalidade, forca, inteligencia, agilidade, destreza);
        this.arcano = arcano;
    }

    public double getArcano() {
        return arcano;
    }

    public void setArcano(double arcano) {
        this.arcano = arcano;
    }
}
