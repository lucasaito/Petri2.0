package com.example.demo.controller;

import com.example.demo.model.Aprendiz;
import com.example.demo.model.Espadachim;
import com.example.demo.repository.EspadachimRepository;
import com.example.demo.repository.MagoRepository;
import com.example.demo.service.EspadachimService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/espadachim")
public class EspadachimController {

    @Autowired
    EspadachimService espadachimService;

    @GetMapping
    public List<Espadachim> listarEspadachim() {
        return espadachimService.listar();
    }

    @PostMapping
    public Espadachim criar (@RequestBody Espadachim espadachim) {
        return espadachimService.criar(espadachim);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@RequestBody Espadachim espadachim, @PathVariable Long id) {
        if (espadachimService.atualizar(espadachim, id) == null) {
            String mensagem = "O id informado não existe";
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(mensagem);
        } else {
            return ResponseEntity.ok(espadachim);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletar(@PathVariable Long id) {
        if(espadachimService.deletar(id)) {
            String mensagem = "O id " + id + " foi removido com sucesso.";
            return ResponseEntity.status(HttpStatus.OK).body(mensagem);
        } else {
            String mensagem = "O id informado não existe";
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(mensagem);
        }
    }

    @GetMapping("/qtd")
    public int qtdEspadachim() {
        return espadachimService.qntEspadachim();
    }

    @GetMapping("/{id}")
    public Optional<Espadachim> buscarPorID(@PathVariable Long id) {
        return espadachimService.buscaPorID(id);
    }
    @DeleteMapping("/all")
    public void deleteAll(){ espadachimService.deletarAll(); }
}
