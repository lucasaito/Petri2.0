package com.example.demo.repository;

import com.example.demo.model.Arqueiro;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ArqueiroRepository extends JpaRepository<Arqueiro,Long> {
}
