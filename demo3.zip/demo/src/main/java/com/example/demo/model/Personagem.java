package com.example.demo.model;

import jakarta.persistence.MappedSuperclass;
import org.hibernate.validator.constraints.UniqueElements;

@MappedSuperclass
public abstract class Personagem {
    private String apelido;

    public Personagem (){
    }

    public Personagem(String apelido) {
        this.apelido = apelido;
    }

    public String getApelido() {
        return apelido;
    }

    public void setApelido(String apelido) {
        this.apelido = apelido;
    }
}
