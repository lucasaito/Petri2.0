package com.example.demo.service;

import com.example.demo.model.Aprendiz;
import com.example.demo.model.Arqueiro;
import com.example.demo.repository.ArqueiroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ArqueiroService {

    @Autowired
    ArqueiroRepository arqueiroRepository;

    public List<Arqueiro> listarArqueiro() {
        return arqueiroRepository.findAll();
    }

    public Arqueiro criar(Arqueiro arqueiro) {
        return arqueiroRepository.save(arqueiro);
    }

    public Arqueiro atualizar(Arqueiro arqueiro, Long id) {
        if(verificaID(id)) {
            //verdadeiro
            arqueiro.setId(id);
            return arqueiroRepository.save(arqueiro);
        }
        return null;
    }

    private boolean verificaID(Long id) {
        if(arqueiroRepository.existsById(id)) {
            return true;
        } else {
            return false;
        }
    }

    public boolean deletar(Long id) {
        if(verificaID(id)) {
            arqueiroRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }

    public int qntArqueiro() {
        return arqueiroRepository.findAll().size();
    }

    public Optional<Arqueiro> buscaPorID(Long id) {
        return arqueiroRepository.findById(id);
    }
    public void deletarAll (){
        arqueiroRepository.deleteAll();
    }
    public List<Arqueiro> mPrecisao(double precisao){
        List<Arqueiro> precisaoMaior = new ArrayList();
        for (Arqueiro arqueiro:arqueiroRepository.findAll()){
            if (arqueiro.getPrecisao() >= precisao){
                precisaoMaior.add(arqueiro);
            }
        }
        return precisaoMaior;
    }

}
