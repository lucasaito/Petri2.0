package com.example.demo.controller;

import com.example.demo.model.Administrador;
import com.example.demo.service.AdministradorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/administrador")
public class AdministradorController {

    @Autowired
    AdministradorService administradorService;

    @GetMapping
    public List<Administrador> listarAdministrador() {
        return administradorService.listar();
    }

    @PostMapping
    public Administrador criar (@RequestBody Administrador administrador) {
        return administradorService.criar(administrador);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@RequestBody Administrador administrador, @PathVariable Long id) {
        if (administradorService.atualizar(administrador, id) == null) {
            String mensagem = "O id informado não existe";
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(mensagem);
        } else {
            return ResponseEntity.ok(administrador);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletar(@PathVariable Long id) {
        if(administradorService.deletar(id)) {
            String mensagem = "O id " + id + " foi removido com sucesso.";
            return ResponseEntity.status(HttpStatus.OK).body(mensagem);
        } else {
            String mensagem = "O id informado não existe";
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(mensagem);
        }
    }


    @GetMapping("/qtd")
    public int qntAdministrador() {
        return administradorService.qntAdministrador();
    }

    @GetMapping("/{id}")
    public Optional<Administrador> buscarPorID(@PathVariable Long id) {
        return administradorService.buscaPorID(id);
    }
    @DeleteMapping("/all")
    public void deleteAll(){ administradorService.deletarAll(); }
}
