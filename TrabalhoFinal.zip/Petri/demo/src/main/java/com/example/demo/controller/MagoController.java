package com.example.demo.controller;

import com.example.demo.model.Arqueiro;
import com.example.demo.model.Mago;
import com.example.demo.service.MagoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/mago")
public class MagoController {

    @Autowired
    MagoService magoService;

    @GetMapping
    public List<Mago> listarMago() {
        return magoService.listar();
    }

    @PostMapping
    public Mago criar (@RequestBody Mago mago) {
        return magoService.criar(mago);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@RequestBody Mago mago, @PathVariable Long id) {
        if (magoService.atualizar(mago, id) == null) {
            String mensagem = "O id informado não existe";
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(mensagem);
        } else {
            return ResponseEntity.ok(mago);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletar(@PathVariable Long id) {
        if(magoService.deletar(id)) {
            String mensagem = "O id " + id + " foi removido com sucesso.";
            return ResponseEntity.status(HttpStatus.OK).body(mensagem);
        } else {
            String mensagem = "O id informado não existe";
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(mensagem);
        }
    }

    @GetMapping("/qtd")
    public int qtdMago() {
        return magoService.qntMago();
    }

    @GetMapping("/{id}")
    public Optional<Mago> buscarPorID(@PathVariable Long id) {
        return magoService.buscaPorID(id);
    }

    @DeleteMapping("/all")
    public void deleteAll(){ magoService.deletarAll(); }

    @GetMapping("/arcano/{arcano}")
    public List<Mago> arcanoMagos (@PathVariable double arcano) {
        return magoService.mArcano(arcano);
    }
}
