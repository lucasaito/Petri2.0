package com.example.demo.service;

import com.example.demo.model.Aprendiz;
import com.example.demo.repository.AprendizRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class AprendizService implements PersonagemService<Aprendiz>{
    @Autowired
    AprendizRepository aprendizRepository;

    @Override
    public List<Aprendiz> listar() {
        return aprendizRepository.findAll();
    }

    @Override
    public Aprendiz criar(Aprendiz aprendiz) {
        return aprendizRepository.save(aprendiz);
    }

    @Override
    public Aprendiz atualizar(Aprendiz aprendiz, Long id) {
        if(verificaID(id)) {
            aprendiz.setId(id);
            return aprendizRepository.save(aprendiz);
        }
        return null;
    }

    @Override
    public boolean deletar(Long id) {
        if(verificaID(id)) {
            aprendizRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }

    private boolean verificaID(Long id) {
        if(aprendizRepository.existsById(id)) {
            return true;
        } else {
            return false;
        }
    }

    public int qntAprendiz() {
        return aprendizRepository.findAll().size();
    }

    public Optional<Aprendiz> buscaPorID(Long id) {
        return aprendizRepository.findById(id);
    }

    public void deletarAll (){
        aprendizRepository.deleteAll();
    }

}
