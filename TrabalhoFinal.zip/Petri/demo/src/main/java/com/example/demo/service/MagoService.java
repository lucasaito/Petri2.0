package com.example.demo.service;

import com.example.demo.model.Arqueiro;
import com.example.demo.model.Espadachim;
import com.example.demo.model.Mago;
import com.example.demo.repository.MagoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Service
public class MagoService implements PersonagemService<Mago>{
    @Autowired
    MagoRepository magoRepository;

    @Override
    public List<Mago> listar() {
        return magoRepository.findAll();
    }

    @Override
    public Mago criar(Mago mago) {
        return magoRepository.save(mago);
    }

    @Override
    public Mago atualizar(Mago mago, Long id) {
        if(verificaID(id)) {
            mago.setId(id);
            return magoRepository.save(mago);
        }
        return null;
    }

    @Override
    public boolean deletar(Long id) {
        if(verificaID(id)) {
            magoRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }

    private boolean verificaID(Long id) {
        if(magoRepository.existsById(id)) {
            return true;
        } else {
            return false;
        }
    }

    public int qntMago() {
        return magoRepository.findAll().size();
    }

    public Optional<Mago> buscaPorID(Long id) {
        return magoRepository.findById(id);
    }

    public void deletarAll (){
        magoRepository.deleteAll();
    }

    public List<Mago> mArcano(double arcano){
        List<Mago> arcanoMaior = new ArrayList();
        for (Mago mago:magoRepository.findAll()){
            if (mago.getArcano() >= arcano){
                arcanoMaior.add(mago);
            }
        }
        return arcanoMaior;
    }
}