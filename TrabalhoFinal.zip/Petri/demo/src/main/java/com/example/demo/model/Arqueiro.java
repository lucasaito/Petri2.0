package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Arqueiro extends Aprendiz {

    private double precisao;

    public Arqueiro() {
    }

    public Arqueiro(String apelido, int nivel, double vitalidade, double forca, double inteligencia, double agilidade, double destreza, double precisao) {
        super(apelido, nivel, vitalidade, forca, inteligencia, agilidade, destreza);
        this.precisao = precisao;
    }

    public double getPrecisao() {
        return precisao;
    }

    public void setPrecisao(double precisao) {
        this.precisao = precisao;
    }
}
