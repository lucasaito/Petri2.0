package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class Administrador extends Personagem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private long chave;
    private String cargo;

    public Administrador() {
    }

    public Administrador(String apelido, long chave, String cargo) {
        super(apelido);
        this.chave = chave;
        this.cargo = cargo;
    }

    public String getCargo() {
        return cargo;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public long getChave() {
        return chave;
    }

    public void setChave(long chave) {
        this.chave = chave;
    }
}
