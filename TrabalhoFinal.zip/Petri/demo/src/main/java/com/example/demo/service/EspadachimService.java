package com.example.demo.service;

import com.example.demo.model.Arqueiro;
import com.example.demo.model.Espadachim;
import com.example.demo.repository.EspadachimRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Service
public class EspadachimService implements PersonagemService<Espadachim> {

    @Autowired
    EspadachimRepository espadachimRepository;

    @Override
    public List<Espadachim> listar() {
        return espadachimRepository.findAll();    }

    @Override
    public Espadachim criar(Espadachim espadachim) {
        return espadachimRepository.save(espadachim);
    }

    @Override
    public Espadachim atualizar(Espadachim espadachim, Long id) {
        if(verificaID(id)) {
            espadachim.setId(id);
            return espadachimRepository.save(espadachim);
        }
        return null;
    }

    @Override
    public boolean deletar(Long id) {
        if(verificaID(id)) {
            espadachimRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }

    private boolean verificaID(Long id) {
        if(espadachimRepository.existsById(id)) {
            return true;
        } else {
            return false;
        }
    }

    public int qntEspadachim() {
        return espadachimRepository.findAll().size();
    }

    public Optional<Espadachim> buscaPorID(Long id) {
        return espadachimRepository.findById(id);
    }
    public void deletarAll (){
        espadachimRepository.deleteAll();
    }

    public List<Espadachim> mFortitude(double fortitude){
        List<Espadachim> fortitudeMaior = new ArrayList();
        for (Espadachim espadachim:espadachimRepository.findAll()){
            if (espadachim.getFortitude() >= fortitude){
                fortitudeMaior.add(espadachim);
            }
        }
        return fortitudeMaior;
    }
}
