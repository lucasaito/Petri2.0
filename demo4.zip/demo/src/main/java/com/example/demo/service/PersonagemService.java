package com.example.demo.service;

import java.util.List;
import com.example.demo.model.Personagem;

public interface PersonagemService <T extends Personagem> {
    List<T> listar();
    T criar (T t);
    T atualizar (T t, Long id);
    boolean deletar(Long id);
}
