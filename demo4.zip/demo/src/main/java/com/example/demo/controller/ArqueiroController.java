package com.example.demo.controller;

import com.example.demo.model.Arqueiro;
import com.example.demo.service.ArqueiroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/arqueiro")
public class ArqueiroController {

    @Autowired
    ArqueiroService arqueiroService;

    @GetMapping
    public List<Arqueiro> listarEspadachim() {
        return arqueiroService.listarArqueiro();
    }

    @PostMapping
    public Arqueiro criar (@RequestBody Arqueiro arqueiro) {
        return arqueiroService.criar(arqueiro);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@RequestBody Arqueiro arqueiro, @PathVariable Long id) {
        if (arqueiroService.atualizar(arqueiro, id) == null) {
            String mensagem = "O id informado não existe";
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(mensagem);
        } else {
            return ResponseEntity.ok(arqueiro);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletar(@PathVariable Long id) {
        if(arqueiroService.deletar(id)) {
            String mensagem = "O id " + id + " foi removido com sucesso.";
            return ResponseEntity.status(HttpStatus.OK).body(mensagem);
        } else {
            String mensagem = "O id informado não existe";
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(mensagem);
        }
    }

    @GetMapping("/qtd")
    public int qntArqueiro() {
        return arqueiroService.qntArqueiro();
    }

    @GetMapping("/{id}")
    public Optional<Arqueiro> buscarPorID(@PathVariable Long id) {
        return arqueiroService.buscaPorID(id);
    }
    @DeleteMapping("/all")
    public void deleteAll(){ arqueiroService.deletarAll(); }

    @GetMapping("/precisao/{precisao}")
    public List<Arqueiro> precisaArqueiros (@PathVariable double precisao) {
        return arqueiroService.mPrecisao(precisao);
    }
}
