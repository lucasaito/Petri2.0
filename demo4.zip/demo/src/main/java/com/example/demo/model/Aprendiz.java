package com.example.demo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class Aprendiz extends Personagem{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private int nivel;
    private double vitalidade;
    private double forca;
    private double inteligencia;
    private double agilidade;
    private double destreza;

    public Aprendiz() {
    }

    public Aprendiz(String apelido, int nivel, double vitalidade, double forca, double inteligencia, double agilidade, double destreza) {
        super(apelido);
        this.nivel = nivel;
        this.vitalidade = vitalidade;
        this.forca = forca;
        this.inteligencia = inteligencia;
        this.agilidade = agilidade;
        this.destreza = destreza;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public double getVitalidade() {
        return vitalidade;
    }

    public void setVitalidade(double vitalidade) {
        this.vitalidade = vitalidade;
    }

    public double getForca() {
        return forca;
    }

    public void setForca(double forca) {
        this.forca = forca;
    }

    public double getInteligencia() {
        return inteligencia;
    }

    public void setInteligencia(double inteligencia) {
        this.inteligencia = inteligencia;
    }

    public double getAgilidade() {
        return agilidade;
    }

    public void setAgilidade(double agilidade) {
        this.agilidade = agilidade;
    }

    public double getDestreza() {
        return destreza;
    }

    public void setDestreza(double destreza) {
        this.destreza = destreza;
    }
}
