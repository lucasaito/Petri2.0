package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Espadachim extends Aprendiz {

    private double fortitude;

    public Espadachim( int nivel, double vitalidade, double forca, double inteligencia, double agilidade, double destreza, String apelido, double fortitude) {
        super(nivel, vitalidade, forca, inteligencia, agilidade, destreza, apelido);
        this.fortitude = fortitude;
    }

    public double getFortitude() {
        return fortitude;
    }

    public void setFortitude(double fortitude) {
        this.fortitude = fortitude;
    }
}
