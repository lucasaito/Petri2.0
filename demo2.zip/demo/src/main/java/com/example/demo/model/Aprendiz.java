package com.example.demo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
abstract class Aprendiz{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private int nivel;
    private double vitalidade;
    private double forca;
    private double inteligencia;
    private double agilidade;
    private double destreza;
    private String apelido;


    public Aprendiz(int nivel, double vitalidade, double forca, double inteligencia, double agilidade, double destreza, String apelido) {
        this.nivel = nivel;
        this.vitalidade = vitalidade;
        this.forca = forca;
        this.inteligencia = inteligencia;
        this.agilidade = agilidade;
        this.destreza = destreza;
        this.apelido = apelido;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getApelido() {
        return apelido;
    }

    public void setApelido(String apelido) {
        this.apelido = apelido;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public double getVitalidade() {
        return vitalidade;
    }

    public void setVitalidade(double vitalidade) {
        this.vitalidade = vitalidade;
    }

    public double getForca() {
        return forca;
    }

    public void setForca(double forca) {
        this.forca = forca;
    }

    public double getInteligencia() {
        return inteligencia;
    }

    public void setInteligencia(double inteligencia) {
        this.inteligencia = inteligencia;
    }

    public double getAgilidade() {
        return agilidade;
    }

    public void setAgilidade(double agilidade) {
        this.agilidade = agilidade;
    }

    public double getDestreza() {
        return destreza;
    }

    public void setDestreza(double destreza) {
        this.destreza = destreza;
    }
}
