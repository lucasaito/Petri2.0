package com.example.demo.controller;

import com.example.demo.model.Espadachim;
import com.example.demo.repository.EspadachimRepository;
import com.example.demo.repository.MagoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/espadachim")
public class EspadachimController {

    @Autowired
    EspadachimRepository espadachimRepository;

    @GetMapping
    public List<Espadachim> listarEspadachim() {
        return espadachimRepository.findAll();
    }

    @PostMapping
    public Espadachim criar (@RequestBody Espadachim espadachim) {
        return espadachimRepository.save(espadachim);
    }
}
