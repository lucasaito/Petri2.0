package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Mago extends Aprendiz{

    private double arcano;


    public Mago(int nivel, double vitalidade, double forca, double inteligencia, double agilidade, double destreza, String apelido, double arcano) {
        super(nivel, vitalidade, forca, inteligencia, agilidade, destreza, apelido);
        this.arcano = arcano;
    }

    public double getArcano() {
        return arcano;
    }

    public void setArcano(double arcano) {
        this.arcano = arcano;
    }
}
