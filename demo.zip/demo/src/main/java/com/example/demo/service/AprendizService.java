package com.example.demo.service;

import com.example.demo.model.Aprendiz;
import com.example.demo.repository.AprendizRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AprendizService {

    @Autowired
    AprendizRepository aprendizRepository;

    public List<Aprendiz> listarAprendiz() {
        return aprendizRepository.findAll();
    }

    public Aprendiz criar(Aprendiz aprendiz) {
        return aprendizRepository.save(aprendiz);
    }

    public Aprendiz atualizar(Aprendiz aprendiz, Long id) {
        if(verificaID(id)) {
            //verdadeiro
            aprendiz.setId(id);
            return aprendizRepository.save(aprendiz);
        }
        return null;
    }

    private boolean verificaID(Long id) {
        if(aprendizRepository.existsById(id)) {
            return true;
        } else {
            return false;
        }
    }

    public boolean deletar(Long id) {
        if(verificaID(id)) {
            aprendizRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }

    public int qntAprendiz() {
        return aprendizRepository.findAll().size();
    }

    public Optional<Aprendiz> buscaPorID(Long id) {
        return aprendizRepository.findById(id);
    }
}
