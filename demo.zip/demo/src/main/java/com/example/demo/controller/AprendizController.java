package com.example.demo.controller;

import com.example.demo.model.Aprendiz;
import com.example.demo.service.AprendizService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/aprendiz")
public class AprendizController {

    @Autowired
    AprendizService aprendizService;

    @GetMapping
    public List<Aprendiz> listarAprendiz() {
        return aprendizService.listarAprendiz();
    }

    @PostMapping
    public Aprendiz criar(@Valid @RequestBody Aprendiz aprendiz) {
        return aprendizService.criar(aprendiz);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> atualizar(@RequestBody Aprendiz aprendiz, @PathVariable Long id) {
        //return funcionarioService.atualizar(funcionario, id);
        if(aprendizService.atualizar(aprendiz, id) == null) {
            //O id não foi encontrado
            //return ResponseEntity.notFound().build();
            String mensagem = "O id informado não existe";
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(mensagem);
        } else {
            //O id foi encontrado
            return ResponseEntity.ok(aprendiz);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletar(@PathVariable Long id) {
        if(aprendizService.deletar(id)) {
            String mensagem = "O id " + id + " foi removido com sucesso.";
            return ResponseEntity.status(HttpStatus.OK).body(mensagem);
        } else {
            String mensagem = "O id informado não existe";
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(mensagem);
        }
    }

    @GetMapping("/qtd")
    public int qtdAprendiz() {
        return aprendizService.qntAprendiz();
    }

    @GetMapping("/{id}")
    public Optional<Aprendiz> buscarPorID(@PathVariable Long id) {
        return aprendizService.buscaPorID(id);
    }



}
