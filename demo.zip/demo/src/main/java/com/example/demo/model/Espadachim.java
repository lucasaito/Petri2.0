package com.example.demo.model;

import jakarta.persistence.Entity;

@Entity
public class Mago extends Aprendiz {
    private double fortitude;


    public Espadachim() {
    }

    public Espadachim( int nivel ,double vitalidade, double forca, double inteligencia, double agilidade, double destreza, double fortitude) {
        super(nivel, vitalidade, forca, inteligencia, agilidade, destreza);
        this.fortitude = fortitude;

    }

    public double getFortitude() {
        return fortitude;
    }

    public void setFortitude(double fortitude) {
        this.fortitude = fortitude;
    }
}
