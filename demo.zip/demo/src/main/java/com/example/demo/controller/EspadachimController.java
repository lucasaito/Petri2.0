package com.example.demo.controller;

import com.example.demo.model.Espadachim;
import com.example.demo.repository.MagoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/espadachim")
public class EspadachimController {

    @Autowired
    MagoRepository magoRepository;

    @GetMapping
    public List<Espadachim> listarEspadachim() {
        return magoRepository.findAll();
    }

    @PostMapping
    public Espadachim criar (@RequestBody Espadachim espadachim) {
        return magoRepository.save(espadachim);
    }
}
