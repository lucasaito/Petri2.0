package com.example.demo.model;

import jakarta.persistence.Entity;

@Entity
public class Mago extemds Aprendiz{
    private double arcano;


    public Mago() {
    }

    public Mago( int nivel ,double vitalidade, double forca, double inteligencia, double agilidade, double destreza, double arcano) {
        super(nivel, vitalidade, forca, inteligencia, agilidade, destreza);
        this.arcano = arcano;

    }

    public double getArcano() {
        return arcano;
    }

    public void setArcano(double arcano) {
        this.arcano = arcano;
    }
}
